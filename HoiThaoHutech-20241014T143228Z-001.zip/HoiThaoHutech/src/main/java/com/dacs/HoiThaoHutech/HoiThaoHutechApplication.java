package com.dacs.HoiThaoHutech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HoiThaoHutechApplication {

	public static void main(String[] args) {
		SpringApplication.run(HoiThaoHutechApplication.class, args);
	}

}
