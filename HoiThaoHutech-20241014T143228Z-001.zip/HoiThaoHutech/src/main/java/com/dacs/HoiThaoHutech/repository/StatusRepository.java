package com.dacs.HoiThaoHutech.repository;

import com.dacs.HoiThaoHutech.models.Status;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StatusRepository extends JpaRepository<Status, Integer> {
}
