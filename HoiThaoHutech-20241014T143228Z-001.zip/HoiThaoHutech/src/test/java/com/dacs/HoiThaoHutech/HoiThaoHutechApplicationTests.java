package com.dacs.HoiThaoHutech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoiThaoHutechApplicationTests {

	@Test
	void contextLoads() {
	}

}
